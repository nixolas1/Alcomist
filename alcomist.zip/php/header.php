<?php header('Content-Type: text/html; charset=utf-8'); ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="static/css/bootstrap.min.css">
<script src="static/js/jquery-1.11.1.min.js"></script>
<script src="static/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="static/css/custom_theme.css">
<link rel="stylesheet" href="static/css/style.css">
<link rel="icon" type="image/png" href="static/images/favicon.png"/>